/*

NAME: BANA DAWIT HUNDE
ID: 2245

 */
package StudentRegistration;

public class Student {
    private int studentId;
    private String name;
    private String fatherName;
    private String grandF;
    private String motherName;
    private String phoneNumber;
    private String studentDoB;
    private String studentRegion;
    private int yearOfRegistration;


    private String studentGender;

    public Student(int studentId, String name, String fatherName, String grandF, String motherName,
                   String phoneNumber,String studentGender, String studentDoB, String studentRegion, int yearOfRegistration  ) {
        this.studentId = studentId;
        this.name = name;
        this.fatherName = fatherName;
        this.grandF = grandF;
        this.motherName = motherName;
        this.phoneNumber = phoneNumber;
        this.studentDoB = studentDoB;
        this.studentRegion = studentRegion;
        this.yearOfRegistration = yearOfRegistration;
        this.studentGender = studentGender;

    }

    public int getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }
    public String getFatherName() {
        return fatherName;
    }
    public String getMotherName() {
        return motherName;
    }
    public String getGrandF() {
        return grandF;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getStudentDoB() {
        return studentDoB;
    }
    public String getStudentRegion() {
        return studentRegion;
    }

    public int getYearOfRegistration() {
        return yearOfRegistration;
    }

    public String getStudentGender(){
        return studentGender;
    }

    @Override
    public String toString() {
        return "Student [ID: " + studentId + ", Name: " + name +", father name: "+ fatherName+
                ", Grand father name: " + grandF + ", Mother name: "+ motherName +
                ", phone number: "+ phoneNumber+ ", Gender: " + studentGender +
                ", Date Of Birth: "+studentDoB + ", Year Of Registrarion: "+ yearOfRegistration +
                ", Region: "+ studentRegion + "]\n If you want to see this in database go to mysql and retrieve the students table!";
    }
}
