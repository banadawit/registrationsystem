/*

NAME: BANA DAWIT HUNDE
ID: 2245

 */


package StudentRegistration;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentRegistrationSystem1 {
    private static ArrayList<Student> students = new ArrayList<>();
    private static ArrayList<Course> courses = new ArrayList<>();
    private static ArrayList<Registration> registrations = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Student Registration System Menu:");
            System.out.println("1. Register Student");
            System.out.println("2. Add Course");
            System.out.println("3. Register Student for Course");
            System.out.println("4. List of Students");
            System.out.println("5. List of Courses");
            System.out.println("6. List of Registrations");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    try{
                        System.out.print("Enter ID: ");
                        int studentId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Student name: ");
                        String studentName = scanner.nextLine();

                        System.out.print("Enter father name: ");
                        String fatherName = scanner.next();
                        System.out.print("Enter grandfather name: ");
                        String grandF = scanner.next();
                        System.out.print("Enter mother name: ");
                        String motherName = scanner.next();
                        scanner.nextLine();
                        System.out.print("Enter Mobile phone number: ");
                        String phoneNumber = scanner.nextLine();

                        System.out.print("Enter the Gender of Student: ");
                        String studentGender = scanner.nextLine();
                        System.out.print("Enter Student DoB: ");
                        String studentDoB = scanner.nextLine();
                        System.out.print("Enter the student Region: ");
                        String studentRegion = scanner.nextLine();
                        System.out.print("Enter the year of Registration: ");
                        int yearOfRegistration = scanner.nextInt();

                        registerStudent(studentId,studentName,fatherName, grandF,
                                motherName, phoneNumber, studentGender,studentDoB,
                                studentRegion,yearOfRegistration);
                        break;
                    }catch (Exception e){
                        System.out.println(e.getMessage());
                        System.exit(0);  // if the error exist in this code automatically it stop the execution
                    }
                case 2:
                    System.out.print("Enter course code: ");
                    String courseCode = scanner.nextLine();
                    System.out.print("Enter course name: ");
                    String courseName = scanner.nextLine();
                    addCourse(courseCode, courseName);
                    break;
                case 3:
                    try {
                        System.out.print("Enter student ID: ");
                        int studentId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter course code: ");
                        courseCode = scanner.nextLine();
                        registerStudentForCourse(studentId, courseCode);
                        break;
                    }catch (Exception e){
                        System.out.println(e.getMessage());
                    }

                case 4:
                    listStudents();
                    break;
                case 5:
                    listCourses();
                    break;
                case 6:
                    listRegistrations();
                    break;
                case 0:
                    System.out.println("Exiting Student Registration System. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void registerStudent(int studentId, String studentName, String fatherName, String grandF, String motherName,
                                        String phoneNumber, String studentGender,
                                        String studentDoB, String studentRegion, int yearOfRegistration) {
        Student student = new Student(studentId, studentName, fatherName, grandF,
                motherName, phoneNumber, studentGender,
                studentDoB, studentRegion, yearOfRegistration);
        students.add(student);
        try ( // IN THIS USER NAME AND THE PASSWORD HAVE TO YOUR'S!
              // and also the database name  that you create in you database......... "jbctry" is mine

                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbctry", "root", "banned1234")) {
            Statement statement = connection.createStatement();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS students ("
                    + "id INT PRIMARY KEY,"
                    + "name VARCHAR(255),"
                    + "father_name VARCHAR(255),"
                    + "grand_father_name VARCHAR(255),"
                    + "mother_name VARCHAR(255),"
                    + "phone_number VARCHAR(15),"
                    + "gender VARCHAR(10),"
                    + "dob VARCHAR(10),"
                    + "region VARCHAR(255),"
                    + "year_of_registration INT"
                    + ")";


            statement.executeUpdate(createTableSQL);

            String sql = "INSERT INTO students (id, name, father_name, " +
                    "grand_father_name, mother_name, " +
                    "phone_number, gender," +
                    " dob, region, year_of_registration)" +
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement statement2 = connection.prepareStatement(sql);
            statement2.setInt(1, studentId);
            statement2.setString(2, studentName);
            statement2.setString(3, fatherName);
            statement2.setString(4, grandF);
            statement2.setString(5, motherName);
            statement2.setString(6, phoneNumber);
            statement2.setString(7, studentGender);
            statement2.setString(8, studentDoB);
            statement2.setString(9, studentRegion);
            statement2.setInt(10, yearOfRegistration);

            int rowsAffected = statement2.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("\nStudent registered: " + student);
                System.out.println();
            }
        } catch (SQLException e) {
            System.out.println("An error occurred while registering the student: " + e.getMessage());
        }
    }


    private static void addCourse(String courseCode, String courseName) {
        Course course = new Course(courseCode, courseName);
        courses.add(course);
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbctry", "root", "banned1234")) {
            Statement statement1 = connection.createStatement();
            String createTableSQL = "CREATE TABLE IF NOT EXISTS courses ("
                    + "course_code INT PRIMARY KEY,"
                    + "course_name VARCHAR(255)" +
                    ")";

            statement1.executeUpdate(createTableSQL);

            String sql = "INSERT INTO courses (course_code, course_name) VALUES (?, ?)";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, courseCode);
            statement.setString(2, courseName);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Course added: " + course);
                System.out.println();
            }
        } catch (SQLException e) {
            System.out.println("An error occurred while adding course: " + e.getMessage());
        }

    }

    private static void registerStudentForCourse(int studentId, String courseCode) {

        Student student = findStudentById(studentId);
        Course course = findCourseByCode(courseCode);

        if (student != null && course != null) {
            Registration registration = new Registration(student, course);
            registrations.add(registration);
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbctry", "root", "banned1234")) {
                Statement statement1 = connection.createStatement();
                String createTableSQL = "CREATE TABLE IF NOT EXISTS registration ("
                        + "student VARCHAR(255),"
                        + "course_name VARCHAR(255)" +
                        ")";
                statement1.executeUpdate(createTableSQL);

                String sql = "INSERT INTO registration (student, course_name) VALUES (?, ?)";
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.setString(1, student.getName());
                statement.setString(2, course.getCourseName());

                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Student registered for course: " + registration);
                    System.out.println();
                }
            } catch (SQLException e) {
                System.out.println("An error occurred while adding course: " + e.getMessage());
            }

        } else {
            System.out.println("Student or course not found. Please check the student ID or course code.");
        }
    }

    private static Student findStudentById(int studentId) {
        for (Student student : students) {
            if (student.getStudentId() == studentId) {
                return student;
            }
        }
        return null;
    }

    private static Course findCourseByCode(String courseCode) {
        for (Course course : courses) {
            if (course.getCourseCode().equals(courseCode)) {
                return course;
            }
        }
        return null;
    }

    private static void listStudents() {

        if (students.isEmpty()==true){
            System.out.println("THERE IS NO STUDENT REGISTERED YET! ");
            System.out.println();
        }else {
            System.out.println("\nList of Students:");
            for (Student student : students) {  // for each loop
                System.out.println(student);

            }
            System.out.println();
        }

    }

    private static void listCourses() {
        System.out.println("\nList of Courses:");
        for (Course course : courses) {
            System.out.println(course);
        }
        System.out.println();
    }

    private static void listRegistrations() {
        System.out.println("\nList of Registrations:");
        for (Registration registration : registrations) {
            System.out.println(registration);
        }
        System.out.println();
    }
}




